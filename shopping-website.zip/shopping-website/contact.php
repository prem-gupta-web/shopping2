<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    // Save contact message to the database or send it via email
    // For simplicity, we'll just display a thank you message
    echo "Thank you for contacting us, $name!";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/4c729db828.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary sticky-top shadow">
        <div class="container">
            <a class="navbar-brand fw-bold fs-4" href="index.php"><i class="fa fa-mobile-alt"></i> All To All Mobile</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse text-center" id="navbarNav">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item"><a class="nav-link text-white" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="about.php">About</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="faq.php">FAQ</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="contact.php">Contact</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="feedback.php">FB</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="location.php">Location</a></li>                  
                    <li class="nav-item"><a class="nav-link text-white" href="cart-view.php"><i class="fa fa-shopping-cart"></i> Cart</a></li>
                </ul>
                <ul class="navbar-nav">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li class="nav-item"><a class="btn btn-warning" href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
                    <?php else: ?>
                        <li class="nav-item"><a class="btn btn-light text-primary" href="login.php"><i class="fa fa-user"></i> Login</a></li>
                        <li class="nav-item"><a class="btn btn-light text-primary" href="register.php"><i class="fa fa-user"></i>Register</a></li>

                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

<!-- Contact Section -->
<section class="container my-5">
    <div class="row align-items-center">
        <div class="col-md-6">
            <img src="images/—Pngtree—contact us microphone small icon_7394415.png" class="img-fluid rounded shadow-sm" alt="Contact Us">
        </div>
        <div class="col-md-6">
            <h2 class="fw-bold">Get In Touch</h2>
            <p class="faq-question">We would love to hear from you! Feel free to reach out to us for any queries or support.</p>
            <form method="post" action="">
                <div class="mb-3">
                    <label class="form-label">Your Name</label>
                    <input type="text" name="name" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Your Email</label>
                    <input type="email" name="email" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Your Message</label>
                    <textarea name="message" class="form-control" rows="4" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Send Message</button>
            </form>
        </div>
    </div>
</section>


   <!-- Footer Section -->
   <footer class="bg-dark text-white py-4">
        <div class="container text-center">
            <p class="social-description">Stay connected with us on social media:</p>
            <div class="social-icons">
                <a href="https://www.facebook.com/profile.php?id=100091625616068" class="social-icon"><i class="fa-brands fa-facebook"></i></a>
                <a href="#" class="social-icon"><i class="fa-brands fa-twitter"></i></a>
                <a href="https://www.instagram.com/premguptaa_?utm_source=qr" class="social-icon"><i class="fa-brands fa-instagram"></i></a>
                <a href="#" class="social-icon"><i class="fa-brands fa-linkedin"></i></a>
                <a href="#" class="social-icon"><i class="fa-brands fa-youtube"></i></a>
            </div>
            <p>&copy; 2025 Shopping Website. All Rights Reserved.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
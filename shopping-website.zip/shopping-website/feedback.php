<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

  // Database connection
  include 'config.php';

  // Insert feedback into the database
  $stmt = $conn->prepare("INSERT INTO feedback (name, email, message) VALUES (?, ?, ?)");
  $stmt->bind_param("sss", $name, $email, $message);

  if ($stmt->execute()) {
      echo "Feedback submitted successfully.";
  } else {
      echo "Error: " . $stmt->error;
  }

  $stmt->close();
  $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/4c729db828.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary sticky-top shadow">
        <div class="container">
            <a class="navbar-brand fw-bold fs-4" href="index.php"><i class="fa fa-mobile-alt"></i> All To All Mobile</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse text-center" id="navbarNav">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item"><a class="nav-link text-white" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="about.php">About</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="faq.php">FAQ</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="contact.php">Contact</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="feedback.php">FB</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="location.php">Location</a></li>                  
                    <li class="nav-item"><a class="nav-link text-white" href="cart-view.php"><i class="fa fa-shopping-cart"></i> Cart</a></li>
                </ul>
                <ul class="navbar-nav">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li class="nav-item"><a class="btn btn-warning" href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
                    <?php else: ?>
                        <li class="nav-item"><a class="btn btn-light text-primary" href="login.php"><i class="fa fa-user"></i> Login</a></li>
                        <li class="nav-item"><a class="btn btn-light text-primary" href="register.php"><i class="fa fa-user"></i>Register</a></li>

                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    <main>
        <section>
            <h2>We Value Your Feedback</h2>
            <form method="POST" action="">
            <label for="name" class="form-label"><i class="fa fa-user"></i> Name:</label>
            <input type="text" id="name" name="name" required placeholder="Enter your name">
            <label for="email" class="form-label"><i class="fa fa-envelope"></i> Email:</label>
            <input type="email" name="email" id="email" name="email" required placeholder="Enter your email">
            <label for="message" class="form-label"><i class="fa fa-comments"></i> Message:</label>
            <textarea name="message" name="message" rows="4" required placeholder="Write your feedback"></textarea>
                <button type="submit">Submit</button>
            </form>
        </section>
    </main>
      <!-- Footer Section -->

     <!-- Footer Section -->
    <footer class="bg-dark text-white py-4">
        <div class="container text-center">
            <p class="social-description">Stay connected with us on social media:</p>
            <div class="social-icons">
                <a href="https://www.facebook.com/profile.php?id=100091625616068" class="social-icon"><i class="fa-brands fa-facebook"></i></a>
                <a href="#" class="social-icon"><i class="fa-brands fa-twitter"></i></a>
                <a href="https://www.instagram.com/premguptaa_?utm_source=qr" class="social-icon"><i class="fa-brands fa-instagram"></i></a>
                <a href="#" class="social-icon"><i class="fa-brands fa-linkedin"></i></a>
                <a href="#" class="social-icon"><i class="fa-brands fa-youtube"></i></a>
            </div>
            <p>&copy; 2025 Shopping Website. All Rights Reserved.</p>
        </div>
    </footer>

</body>
</html>
<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include 'config.php';
include 'cart.php';

$cart = new Cart();

// Check if search query is set
$search_query = isset($_GET['search']) ? $_GET['search'] : '';

// Fetch products from the database
if ($search_query) {
    $stmt = $conn->prepare("SELECT * FROM products WHERE name LIKE ? OR description LIKE ?");
    $search_term = '%' . $search_query . '%';
    $stmt->bind_param("ss", $search_term, $search_term);
} else {
    $stmt = $conn->prepare("SELECT * FROM products");
}

$stmt->execute();
$result = $stmt->get_result();

// Handle Add to Cart
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_to_cart'])) {
    $productId = $_POST['product_id'];
    $quantity = 1; // Default quantity

    // Fetch product price from the database
    $stmt = $conn->prepare("SELECT price FROM products WHERE id = ?");
    $stmt->bind_param("i", $productId);
    $stmt->execute();
    $stmt->bind_result($price);
    $stmt->fetch();
    $stmt->close();

    $cart->addProduct($productId, $price, $quantity);
    header("Location: cart-view.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All To All Mobile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/4c729db828.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
</head>
<body>

 <!-- Navigation Bar -->
 <nav class="navbar navbar-expand-lg navbar-dark bg-primary sticky-top shadow">
        <div class="container">
            <a class="navbar-brand fw-bold fs-4" href="index.php"><i class="fa fa-mobile-alt"></i> All To All Mobile</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse text-center" id="navbarNav">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item"><a class="nav-link text-white" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="about.php">About</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="faq.php">FAQ</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="contact.php">Contact</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="feedback.php">FB</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="location.php">Location</a></li>                  
                    <li class="nav-item"><a class="nav-link text-white" href="cart-view.php"><i class="fa fa-shopping-cart"></i> Cart</a></li>
                </ul>
                <ul class="navbar-nav">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li class="nav-item"><a class="btn btn-warning" href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
                    <?php else: ?>
                        <li class="nav-item"><a class="btn btn-light text-primary" href="login.php"><i class="fa fa-user"></i> Login</a></li>
                        <li class="nav-item"><a class="btn btn-light text-primary" href="register.php"><i class="fa fa-user"></i>Register</a></li>

                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

                        
    <!-- Carousel Section -->
<section id="carousel" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="images/15.jpg" class="d-block w-100" >
            <div class="carousel-caption d-none d-md-block">
              <p >Welcome to our All To All Mobile!</p>
            </div>
        </div>
        <div class="carousel-item">
            <img src="images/16.jpg" class="d-block w-100" alt="">
            <div class="carousel-caption d-none d-md-block">
              <p>Discover the best products at unbeatable prices.</p>
            </div>
        </div>
        <div class="carousel-item">
            <img src="images/3.png" class="d-block w-100" alt="">
            <div class="carousel-caption d-none d-md-block">
                 <p>Enjoy a seamless shopping experience.</p>
            </div>
        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</section>

 <!-- Hero Section
 <section class="hero-section text-center text-white d-flex flex-column align-items-center justify-content-center" style="height: 60vh; background: url('images/15.jpg') center/cover;">
        <h1 class="fw-bold">Your One-Stop Mobile Shop</h1>
        <p class="fs-5">Best Deals on Latest Smartphones & Accessories</p>
        <a href="#products" class="btn btn-lg btn-warning mt-3">Shop Now</a>
    </section> -->

   <!-- Search Form -->
   <div class="container mt-4">
        <form method="GET" action="index.php" class="d-flex">
            <input class="form-control me-2" type="search" name="search" placeholder="Search for products" aria-label="Search" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
            <button class="btn btn-outline-success" type="submit">Search</button>
        </form>
    </div>
    
    <!-- Products Section -->
<section id="products" class="products-section">
    <div class="container">
        <h2 class="section-title">Our Products</h2>
        <div class="products-container">
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="product-card">
                        <div class="product-image">
                            <img src="<?php echo $row['image']; ?>" class="card-img-top" alt="<?php echo $row['name']; ?>">
                            <div class="product-content">
                                <h5 class="product-title"><?php echo $row['name']; ?></h5>
                                <p class="product-description"><?php echo $row['description']; ?></p>
                                <p class="product-price"><strong>₹<?php echo $row['price']; ?></strong></p>
                                <form method="POST" action="">
                                    <input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">
                                    <button type="submit" name="add_to_cart" class="btn btn-primary">Add to Cart</button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No products found matching your search criteria.</p>
            <?php endif; ?>
        </div>
    </div>
</section>

    <!-- Review Section -->
    <section class="customer-review-section">
        <h2 class="review-heading">What Our Customers Say</h2>
        <div class="review-carousel">
            <div class="review-card">
                <img src="images/man3.jpg" alt="Customer 1" class="customer-photo">
                <p class="review-text">"The product quality is outstanding! I’m very happy with my purchase."</p>
                <h4 class="customer-name">- sambhav</h4>
            </div>
            <div class="review-card">
                <img src="images/man6.jpg" alt="Customer 2" class="customer-photo">
                <p class="review-text">"Excellent service and fast delivery. Highly recommend this store!"</p>
                <h4 class="customer-name">- rahul </h4>
            </div>
            <div class="review-card">
                <img src="images/man4.jpg" alt="Customer 3" class="customer-photo">
                <p class="review-text">"Loved the variety of options and the helpful customer support team."</p>
                <h4 class="customer-name">- abhishek</h4>
            </div>
        </div>
    </section>

    <!-- Footer Section -->
    <footer class="bg-dark text-white py-4">
        <div class="container text-center">
            <p class="social-description">Stay connected with us on social media:</p>
            <div class="social-icons">
                <a href="https://www.facebook.com/profile.php?id=100091625616068" class="social-icon"><i class="fa-brands fa-facebook"></i></a>
                <a href="#" class="social-icon"><i class="fa-brands fa-twitter"></i></a>
                <a href="https://www.instagram.com/premguptaa_?utm_source=qr" class="social-icon"><i class="fa-brands fa-instagram"></i></a>
                <a href="#" class="social-icon"><i class="fa-brands fa-linkedin"></i></a>
                <a href="#" class="social-icon"><i class="fa-brands fa-youtube"></i></a>
            </div>
            <p>&copy; 2025 Shopping Website. All Rights Reserved.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="script.js"></script>
</body>
</html>